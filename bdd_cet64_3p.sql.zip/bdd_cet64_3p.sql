-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-05-2020 a las 00:38:02
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdd_cet64_3p`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas_cet64`
--

CREATE TABLE `entradas_cet64` (
  `id_entra` int(11) NOT NULL,
  `nombre_prod` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL DEFAULT current_timestamp(),
  `cant_prod` int(10) NOT NULL,
  `id_proo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `entradas_cet64`
--

INSERT INTO `entradas_cet64` (`id_entra`, `nombre_prod`, `fecha`, `cant_prod`, `id_proo`) VALUES
(9, 'Aplicacion realidad aumentada', '2020-05-26', 2, 9),
(13, 'Panel solar', '2020-05-27', 1, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pass_cet64`
--

CREATE TABLE `pass_cet64` (
  `cla_pass` int(11) NOT NULL,
  `userName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `noCuenta` int(20) NOT NULL,
  `rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `pass_cet64`
--

INSERT INTO `pass_cet64` (`cla_pass`, `userName`, `pass`, `noCuenta`, `rol`) VALUES
(1, 'Artyparzival', '34f65b9218de8596a70252533378e82d', 1, 1),
(26, 'Ivancolin', '4590bc0aa56bcffebdfa2c490425365c', 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prod_cet64`
--

CREATE TABLE `prod_cet64` (
  `nombre_prod` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `descrip_prod` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `cant_prod` int(10) NOT NULL,
  `prec_prod` int(10) NOT NULL,
  `foto_pro` text COLLATE utf8_unicode_ci NOT NULL,
  `id_proo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `prod_cet64`
--

INSERT INTO `prod_cet64` (`nombre_prod`, `descrip_prod`, `cant_prod`, `prec_prod`, `foto_pro`, `id_proo`) VALUES
('Aplicacion realidad aumentada', 'app', 2, 100, 'foto', 9),
('Panel solar', 'panel generador de energia', 1, 100, 'P2170007 (2).JPG', 12);

--
-- Disparadores `prod_cet64`
--
DELIMITER $$
CREATE TRIGGER `entradas` AFTER INSERT ON `prod_cet64` FOR EACH ROW BEGIN
    	INSERT INTO entradas_cet64(nombre_prod,cant_prod,id_proo)
        VALUES (new.nombre_prod,new.cant_prod,new.id_proo);
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proo_cet64`
--

CREATE TABLE `proo_cet64` (
  `id_proo` int(11) NOT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `noCuenta` int(20) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `proo_cet64`
--

INSERT INTO `proo_cet64` (`id_proo`, `nombre`, `noCuenta`, `estatus`) VALUES
(9, 'CETis 64', 1, 1),
(12, 'CBT justo sierra', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salidas_cet64`
--

CREATE TABLE `salidas_cet64` (
  `id_salida` int(11) NOT NULL,
  `nombre_prod` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cant_prod` int(10) NOT NULL,
  `fech_salida` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `salidas_cet64`
--

INSERT INTO `salidas_cet64` (`id_salida`, `nombre_prod`, `cant_prod`, `fech_salida`) VALUES
(1, 'Aplicacion realidad ', 2, '2020-05-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_cet64`
--

CREATE TABLE `user_cet64` (
  `noCuenta` int(20) NOT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `apelliP` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `apelliM` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fechNac` date NOT NULL,
  `genero` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `domicilio` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `user_cet64`
--

INSERT INTO `user_cet64` (`noCuenta`, `nombre`, `apelliP`, `apelliM`, `fechNac`, `genero`, `telefono`, `email`, `domicilio`, `estatus`) VALUES
(1, 'Angel Ivan', 'Romero', 'Colin', '2000-08-03', 'H', '1234567891', 'correofalso@gmail.com', 'Toluca', 1),
(2, 'Angel Ivan', 'Romero', 'Colin', '2003-05-03', 'H', '1234567891', 'correofalso@gmail.com', 'morelos 12', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_cet64`
--

CREATE TABLE `ventas_cet64` (
  `cla_vent` int(20) NOT NULL,
  `nombre_prod` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `cant_prod` int(10) NOT NULL,
  `fechVent` date NOT NULL DEFAULT current_timestamp(),
  `noCuenta` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `total_vent` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `ventas_cet64`
--

INSERT INTO `ventas_cet64` (`cla_vent`, `nombre_prod`, `cant_prod`, `fechVent`, `noCuenta`, `total_vent`) VALUES
(1, 'Aplicacion realidad aumentada', 2, '0000-00-00', '01', 1000);

--
-- Disparadores `ventas_cet64`
--
DELIMITER $$
CREATE TRIGGER `salida` AFTER INSERT ON `ventas_cet64` FOR EACH ROW BEGIN 
      INSERT INTO salidas_cet64(nombre_prod,cant_prod)
         VALUES (new.nombre_prod,new.cant_prod);
     END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `entradas_cet64`
--
ALTER TABLE `entradas_cet64`
  ADD PRIMARY KEY (`id_entra`),
  ADD KEY `nombre_prod` (`nombre_prod`),
  ADD KEY `id_proo` (`id_proo`);

--
-- Indices de la tabla `pass_cet64`
--
ALTER TABLE `pass_cet64`
  ADD PRIMARY KEY (`cla_pass`),
  ADD KEY `noCuenta` (`noCuenta`);

--
-- Indices de la tabla `prod_cet64`
--
ALTER TABLE `prod_cet64`
  ADD PRIMARY KEY (`nombre_prod`),
  ADD KEY `prod_cet64_ibfk_1` (`id_proo`);

--
-- Indices de la tabla `proo_cet64`
--
ALTER TABLE `proo_cet64`
  ADD PRIMARY KEY (`id_proo`),
  ADD KEY `noCuenta` (`noCuenta`);

--
-- Indices de la tabla `salidas_cet64`
--
ALTER TABLE `salidas_cet64`
  ADD PRIMARY KEY (`id_salida`);

--
-- Indices de la tabla `user_cet64`
--
ALTER TABLE `user_cet64`
  ADD PRIMARY KEY (`noCuenta`);

--
-- Indices de la tabla `ventas_cet64`
--
ALTER TABLE `ventas_cet64`
  ADD PRIMARY KEY (`cla_vent`),
  ADD KEY `noCuenta` (`noCuenta`),
  ADD KEY `nombre_prod` (`nombre_prod`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `entradas_cet64`
--
ALTER TABLE `entradas_cet64`
  MODIFY `id_entra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `pass_cet64`
--
ALTER TABLE `pass_cet64`
  MODIFY `cla_pass` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `proo_cet64`
--
ALTER TABLE `proo_cet64`
  MODIFY `id_proo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `salidas_cet64`
--
ALTER TABLE `salidas_cet64`
  MODIFY `id_salida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `user_cet64`
--
ALTER TABLE `user_cet64`
  MODIFY `noCuenta` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ventas_cet64`
--
ALTER TABLE `ventas_cet64`
  MODIFY `cla_vent` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `entradas_cet64`
--
ALTER TABLE `entradas_cet64`
  ADD CONSTRAINT `entradas_cet64_ibfk_1` FOREIGN KEY (`nombre_prod`) REFERENCES `prod_cet64` (`nombre_prod`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `entradas_cet64_ibfk_2` FOREIGN KEY (`id_proo`) REFERENCES `proo_cet64` (`id_proo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pass_cet64`
--
ALTER TABLE `pass_cet64`
  ADD CONSTRAINT `pass_cet64_ibfk_1` FOREIGN KEY (`noCuenta`) REFERENCES `user_cet64` (`noCuenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `prod_cet64`
--
ALTER TABLE `prod_cet64`
  ADD CONSTRAINT `prod_cet64_ibfk_1` FOREIGN KEY (`id_proo`) REFERENCES `proo_cet64` (`id_proo`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `proo_cet64`
--
ALTER TABLE `proo_cet64`
  ADD CONSTRAINT `proo_cet64_ibfk_1` FOREIGN KEY (`noCuenta`) REFERENCES `user_cet64` (`noCuenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas_cet64`
--
ALTER TABLE `ventas_cet64`
  ADD CONSTRAINT `ventas_cet64_ibfk_2` FOREIGN KEY (`nombre_prod`) REFERENCES `prod_cet64` (`nombre_prod`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
